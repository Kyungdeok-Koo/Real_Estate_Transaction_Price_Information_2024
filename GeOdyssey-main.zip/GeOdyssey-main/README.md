# GeOdyssey
##### YTN_NEWS에서 북한관련 기사들을 뽑아 Topic별로 관련 주제를 도출하는 시스템

<br>
<br>

## 👨‍💻 Team 👨‍💻
|권미경|김가경|김진형|구경덕|손지현|
|:---:|:---:|:---:|:---:|:---:|
|팀장|팀원|팀원|팀원|팀원|

<br>
<br>

## 진행 방식
![image](https://github.com/Kyungdeok-Koo/first-repository/blob/main/Aiffel_DataScientist_3rd/%EC%8A%A4%ED%81%AC%EB%A6%B0%EC%83%B7%202025-03-21%2017-58-23.png)
<br>
<br>

## 주요 기능
##### TOPIC 간의 유사성 및 관계 구조를 시각화하기 위해 활용
![image](https://github.com/Kyungdeok-Koo/first-repository/blob/main/Aiffel_DataScientist_3rd/%EC%8A%A4%ED%81%AC%EB%A6%B0%EC%83%B7%202025-03-21%2015-35-17.png)
<br>
##### GEOINT Data Visualization 2020-2021
![image](https://github.com/Kyungdeok-Koo/first-repository/blob/main/Aiffel_DataScientist_3rd/%EC%8A%A4%ED%81%AC%EB%A6%B0%EC%83%B7%202025-03-21%2015-35-47.png)

<br>
<br>

## 프로젝트 목적
- #### 방대한 기사 빅데이터를 요약 정리 및 해당분야에 관심있는 독자들에게 제공
  

<br>
